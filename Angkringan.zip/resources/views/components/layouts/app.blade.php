<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

</head>
<body class="font-sans antialiased">
<div class="min-h-screen bg-gray-100">
    <div style="padding: 20px; background-color: #d4dceb; color: #1a202c;display: flex ;justify-content: end; gap: 5px;">
        @if(session('login_as')=='bendahara')
            <a href="{{Route('stok-bendahara')}}" style="background-color: white; padding: 5px; border-radius: 4px">STOCK</a>
            <a href="{{Route('form-pesanan')}}" style="background-color: white; padding: 5px; border-radius: 4px">FORM Pesanan</a>
            <a href="{{Route('menu')}}" style="background-color: white; padding: 5px; border-radius: 4px">MENU</a>
            <a href="{{Route('histori')}}" style="background-color: white; padding: 5px; border-radius: 4px">Pesanan</a>
            <a href="{{Route('logout')}}" style="background-color: white; padding: 5px; border-radius: 4px">LOGOUT</a>
        @elseif(session('login_as')=='serving')
            <a href="{{Route('stok-serving')}}" style="background-color: white; padding: 5px; border-radius: 4px">STOCK</a>
            <a href="{{Route('histori')}}" style="background-color: white; padding: 5px; border-radius: 4px">Pesanan</a>
            <a href="{{Route('logout')}}" style="background-color: white; padding: 5px; border-radius: 4px">LOGOUT</a>
        @elseif(Route::currentRouteName() == 'stok')
            <a href="{{Route('login')}}" style="background-color: white; padding: 5px; border-radius: 4px">LOGIN</a>
        @elseif(Route::currentRouteName() == 'login')
            <a href="{{Route('stok')}}" style="background-color: white; padding: 5px; border-radius: 4px">Home</a>
        @endif
    </div>
    <!-- Page Content -->
    <main>
        {{ $slot }}
    </main>
</div>
</body>
</html>
